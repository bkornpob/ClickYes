﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class CollectDots : MonoBehaviour {

	public AudioClip collectSFX,failSFX;
	public float collectSFXVolume,failSFXVolume;

	// if Dot: play sound, deactive Dot, update score
	// if not-Dot: play sound, deactive not-Dot, update score 
	void OnTriggerEnter2D(Collider2D other){
		
		if (other.tag == "Dot") { // if Dot
			AudioSource.PlayClipAtPoint (collectSFX, this.gameObject.transform.position,collectSFXVolume);
			other.gameObject.SetActive (false);
			TimerController._TC.score++;

		} else if (other.tag == "NotDot") { // if NotDot
			AudioSource.PlayClipAtPoint (failSFX, this.gameObject.transform.position,failSFXVolume);
			other.gameObject.SetActive (false);
			TimerController._TC.score=0;
		}
	}






		
}
