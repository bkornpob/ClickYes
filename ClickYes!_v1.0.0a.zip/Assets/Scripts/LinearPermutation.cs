﻿// Author: KB.GameDev
// kbgamedev.weebly.com
// github.com/bkornpob
// Tested: Unity 5.4.2f2
// Dated: 20170227

using UnityEngine;
using System.Collections;

public static class LinearPermutation{

	/// <summary>
	/// Permutation P(n,r).
	/// randomly draw integers from [0,length) with length=difficulty
	/// no repetition
	/// return, an integer array of length=difficulty, [0,length), no repetition
	/// </summary>
	/// <param name="n">N.</param>
	/// <param name="r">The red component.</param>
	public static int[] Permute(int n, int r){

		// 1. generate temporary array of integers [0,length)
		int[] allowNumber = new int[n];
		for (int i = 0; i < n; i++) {
			allowNumber [i] = i;
		}

		// 2. permutation
		for (int i=0;i<r;i++){
			int index = Random.Range(i,n);
			int temp = allowNumber[i];
			allowNumber [i] = allowNumber [index];
			allowNumber [index] = temp;
		}

		// 3. subset only first r elements
		int[] x = new int[r];
		for (int i=0;i<r;i++){
			x [i] = allowNumber [i];
		}

		return x;
	}
	
}

