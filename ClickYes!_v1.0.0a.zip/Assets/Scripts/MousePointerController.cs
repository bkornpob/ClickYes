﻿using UnityEngine;
using System.Collections;

public class MousePointerController : MonoBehaviour {

	public GameObject mousePointer;

	Vector3 newPosition;

	void Awake(){
		#region deactive mouse pointer
		mousePointer.SetActive (false);
		#endregion
	}

	void Update(){

		#region functionality for mouse on hold
		if (Input.GetMouseButton (0)) { // left mouse is held
			#region	
			// active mouse pointer
			mousePointer.SetActive(true);

			// locate mouse pointer at the click position
			Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			newPosition = ray.origin;
			newPosition.z = 0;

			// move moust pointer to the click position
			mousePointer.transform.position = newPosition;
			#endregion
		} else { // left mouse is not held
			#region
			// deactive mouse pointer
			mousePointer.SetActive(false);
			#endregion
		}
		#endregion

	}

}
