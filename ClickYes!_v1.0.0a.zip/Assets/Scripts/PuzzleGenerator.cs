﻿using UnityEngine;
using System.Collections;

public class PuzzleGenerator : MonoBehaviour {

	public int difficulty = 1; // number of dots spawned in one puzzle loop
	public float timeToNextPuzzle = 1; // time to the next puzzle loop
	public float yesNoRatio = 0.5f; // ratio of yes/no puzzle
	public GameObject[] dots;

	int _lengthOfDots;
	float _time;

	void Awake () {

		_lengthOfDots = dots.Length;
		_time = Time.time;
		DeactiveDots();

	}

	void DeactiveDots(){
		foreach (var a in dots){
			a.SetActive(false);
		}
	}
		
	void Update () {

		#region new puzzle
		if (Time.time < _time + timeToNextPuzzle) { // not generate new puzzle
			return;
		} else { // generate new puzzle
			// define difficulty
			difficulty = difficulty;
			// generate puzzle
			int[] x = LinearPermutation.Permute(_lengthOfDots,_lengthOfDots);
			// output puzzle upto difficulty as maximum
			int count=0;
			foreach(var a in x){
				if (count >= difficulty){ // skip loop if reaching maximum
					continue;
				} else {
					if (!dots[a].active){
						dots[a].SetActive(true);
						float z = Random.Range(0.0f,1.0f);
						bool yes = (z < yesNoRatio);
						dots[a].GetComponent<DotController>().Activate(yes);
						count++;
					} else {
						continue;
					}
				}

			}
			// update _time
			_time = Time.time;
		}
		#endregion

	}

}
