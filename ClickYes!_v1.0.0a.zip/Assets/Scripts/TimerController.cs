﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class TimerController : MonoBehaviour {

	public static TimerController _TC; // will declare itself for static use

	public GameObject mousePointer;
	public GameObject mousePointerController;
	public Text scoreText,deathText;

	public float endTime = 5; // time to end one game loop
	public float restartTime=2; // time to restart a new game loop
	public int winScore = 5; // score to win the game
	public int loseScore = -1; // score to lose the game

	public AudioClip winSFX;
	public float winSFXVolume=1;

	[HideInInspector] public int score=0;
	float tt;
	bool sentinelYes=true;

	void Awake(){
		_TC = this;
		deathText.gameObject.SetActive (false);
		tt = Time.time;
	}

	void Update(){
		// output score
		scoreText.text = "Score: " + score.ToString ();

		// check win by score
		// check lose by score
		// check lose by timeout
		if (score >= winScore) {
			WinLevel ();
		}
		if (score <= loseScore) {
			Death ();
		}
		if (Time.time >= tt + endTime) {
			Death ();
		}

	}

	void WinLevel(){
		
		if (sentinelYes){
			// play sound
			GameObject c = Camera.main.gameObject;
			AudioSource.PlayClipAtPoint (winSFX, c.transform.position,winSFXVolume);

			// do whatever it is for winner
			tt=Time.time;
			deathText.gameObject.SetActive (true);
			deathText.text="WIN";
			mousePointer.SetActive(false);
			mousePointerController.SetActive (false);
			Invoke ("Restart", restartTime);
			sentinelYes = false;
		}



	}

	void Death(){
		
		// deactivate mousePointerController
		mousePointer.SetActive(false);
		mousePointerController.SetActive (false);

		// do whatever it is for loser
		deathText.gameObject.SetActive (true);
		deathText.text="END";
		Invoke ("Restart", restartTime);
	}

	void Restart(){
		deathText.gameObject.SetActive (false);
		mousePointerController.SetActive (true);
		score = 0;
		tt = Time.time;
		sentinelYes = true;
	}

}
