ClickYes!
v1.0.0a

This game is a part of Ohio University Game Developer Association (OUGDA)'s Spring2017 project under the theme "flash game."

Developer: KB.GameDev

Team:
	KB, kbgamedev.weebly.com: I did everything besides...
	Audio from Unity Asset Store: Dustyroom, dustyroom.com
	Sprites from Unity Asset Store: RDR, rdr.artstation.com

Developed under Unity 5.4.2f2.
Recommended resolution: 1920x1080

Audio control:
	CollectSFX
	FailSFX
		are in CollectDots.cs which is attached to Mouse Pointer.
	TimeSFX2
	WinSFX
		are in TimerController.cs which is attached to Timer.

Win-Lose control:
	TimerController.Winlevel()
	TimerController.Death()

Difficulty adjustment:
	DotContoller.timeOut = time which a dot exists after spawned. Adjust this in Dot prefab.
	PuzzleGenerator.difficulty = number of dots spawned in one step.
	PuzzleGenerator.timeToNextPuzzle = time to the next puzzle loop.
	PuzzleGenerator.yesNoRatio = ratio of yes/no puzzle.
	TimerController.endTime = time to end a game loop. It is set to 5 by Default for the flash game project.
	TimerController.winScore = score to win the game.
	TimerController.loseScore = score to lose the game. It is inactive currectly. To active this mechanics, make change in CollectDots.cs
